COBie-style export from the Building Ledger (CSV per sheet, not a validated COBie 2.4 workbook).
Ledger head 017a931e1879ad0bf5cfebf7daa8b613d98f20168437f1bd09289bf97e3ef8d1 at event 239. Positions in the building frame, metres, +Y up.
